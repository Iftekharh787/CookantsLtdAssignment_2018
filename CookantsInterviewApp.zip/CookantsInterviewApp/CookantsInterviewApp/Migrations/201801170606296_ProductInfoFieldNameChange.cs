namespace CookantsInterviewApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ProductInfoFieldNameChange : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.ProductInfoes", "PName", c => c.String(nullable: false));
            AlterColumn("dbo.ProductInfoes", "PDescription", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.ProductInfoes", "PDescription", c => c.String());
            AlterColumn("dbo.ProductInfoes", "PName", c => c.String());
        }
    }
}
