namespace CookantsInterviewApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class version1 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Admins",
                c => new
                    {
                        AId = c.Int(nullable: false, identity: true),
                        AName = c.String(nullable: false),
                        AUserName = c.String(nullable: false),
                        AEmail = c.String(nullable: false),
                        APassword = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.AId);
            
            CreateTable(
                "dbo.Customers",
                c => new
                    {
                        CID = c.Int(nullable: false, identity: true),
                        CName = c.String(nullable: false),
                        CUserName = c.String(nullable: false),
                        CEmail = c.String(nullable: false),
                        CPassword = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.CID);
            
            CreateTable(
                "dbo.ProductInfoes",
                c => new
                    {
                        PID = c.Int(nullable: false, identity: true),
                        PName = c.String(),
                        PPrice = c.Decimal(nullable: false, precision: 18, scale: 2),
                        PDescription = c.String(),
                    })
                .PrimaryKey(t => t.PID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.ProductInfoes");
            DropTable("dbo.Customers");
            DropTable("dbo.Admins");
        }
    }
}
