﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CookantsInterviewApp.Models
{
    public class ProductInfo
    {
        [Key]
        public int PID { get; set; }
        [Required(ErrorMessage = "Product Name Required")]
        [DisplayName("Product Name")]
        public String PName { get; set; }
        [DisplayName("Product Price")]
        [Required(ErrorMessage = "Product Price Required")]
        public decimal PPrice { get; set; }
        [DisplayName("Product Description")]

        [Required(ErrorMessage = "Product Description Required")]
        public string PDescription { get; set; }

    }
}