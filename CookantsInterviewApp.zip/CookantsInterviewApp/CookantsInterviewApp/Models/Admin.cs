﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CookantsInterviewApp.Models
{
    public class Admin
    {
        [Key]
        public int AId { get; set; }

        [Required(ErrorMessage = "Admin Name is Required")]
        [DisplayName("Name")]
        public String AName { get; set; }

        [DisplayName("User Name")]
        [Required(ErrorMessage = "UserName is Required")]
        public String AUserName { get; set; }


        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                           @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                           @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Email Format is Invalid")]
        [Required(ErrorMessage = "Email Must Be Unique")]
        [DisplayName("Email")]
        public string AEmail { get; set; }
        [DisplayName("Password")]
        [Required(ErrorMessage = "Password is Required")]
        [DataType(DataType.Password)]
        public string APassword { get; set; }

    }
}