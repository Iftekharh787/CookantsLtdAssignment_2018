﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace CookantsInterviewApp.Models
{
    public class ProductDbContext : DbContext
    {
        public DbSet<Admin> Admin { get; set; }
        public DbSet<Customer> Customer { get; set; }
        public DbSet<ProductInfo> ProductInfo { get; set; }
       // public DbSet<>  { get; set; }
    }
}