﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CookantsInterviewApp.Models
{
    public class Customer
    {
        [Key]
        public int CID { get; set; }
        [DisplayName("Name")]
        [Required(ErrorMessage = "Name is Required")]
        public String CName { get; set; }
        [DisplayName("User Name")]
        [Required(ErrorMessage = "UserName is Required")]
        public String CUserName { get; set; }

        [DisplayName("Email")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                           @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                           @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Email Format is Invalid")]
        [Required(ErrorMessage = "Email Must Be Unique")]
        public string CEmail { get; set; }
        [DisplayName("Password")]
        [Required(ErrorMessage = "Password is Required")]
        [DataType(DataType.Password)]
        public string CPassword { get; set; }
    }
}