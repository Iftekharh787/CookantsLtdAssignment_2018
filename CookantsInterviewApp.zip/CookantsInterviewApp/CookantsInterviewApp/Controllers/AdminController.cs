﻿using CookantsInterviewApp.Models;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;

namespace CookantsInterviewApp.Controllers
{
    public class AdminController : Controller
    {
        private ProductDbContext db = new ProductDbContext();

        // GET: /Admin/
        public ActionResult Index()
        {

            return View();
        }

        public ActionResult AdminListView()
        {
            if (Session["AdminUserEmail"] != null)
            {
                return View(db.Admin.ToList());
            }
            else
            {
                return RedirectToAction("LoginView", "Customer");
            }
        }

        // GET: /Admin/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Admin admin = db.Admin.Find(id);
            if (admin == null)
            {
                return HttpNotFound();
            }
            return View(admin);
        }


        public ActionResult Adminlogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Adminlogin(Admin admin)
        {

            var check = db.Admin.Any(u => u.AEmail == admin.AEmail && u.APassword == admin.APassword);
            if (check)
            {
                var admins = db.Admin.SingleOrDefault(u => u.AEmail == admin.AEmail && u.APassword == admin.APassword);
                Session["AdminUserEmail"] = admins.AEmail.ToString();
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.message = "Incorrect user name or password!!!";
                return View();
            }

        }

        // GET: /Admin/Create
        public ActionResult Create()
        {

            if (Session["AdminUserEmail"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("LoginView", "Customer");
            }

        }

        // POST: /Admin/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "AId,AName,AUserName,AEmail,APassword")] Admin admin)
        {
            var uniqueEmail = db.Admin.SingleOrDefault(a => a.AEmail == admin.AEmail);
            if (uniqueEmail == null)
            {
                if (ModelState.IsValid)
                {
                    db.Admin.Add(admin);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            else
            {
                ViewBag.UniqueEmailMessage = "Sorry!Email Already Exsit";
            }


            return View(admin);
        }

        // GET: /Admin/Edit/5
        public ActionResult Edit(int? id)
        {
            if (Session["AdminUserEmail"] != null)
            {
                Admin admin = db.Admin.Find(id);
                if (admin == null)
                {
                    return HttpNotFound();
                }
                return View(admin);
            }
            else
            {
                return RedirectToAction("LoginView", "Customer");
            }
        }

        // POST: /Admin/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "AId,AName,AUserName,AEmail,APassword")] Admin admin)
        {

            if (ModelState.IsValid)
            {
                db.Entry(admin).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(admin);
        }

        // GET: /Admin/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Admin admin = db.Admin.Find(id);
            if (admin == null)
            {
                return HttpNotFound();
            }
            return View(admin);
        }

        // POST: /Admin/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Admin admin = db.Admin.Find(id);
            db.Admin.Remove(admin);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
