﻿using CookantsInterviewApp.Models;
using System.Linq;
using System.Net;
using System.Web.Mvc;

namespace CookantsInterviewApp.Controllers
{
    public class CustomerController : Controller
    {
        private ProductDbContext db = new ProductDbContext();

        public ActionResult Index()
        {

            if (Session["AdminUserEmail"] != null)
            {
                return View(db.Customer.ToList());

            }

            return RedirectToAction("RegisterView", "Customer");

        }

        public ActionResult RegisterView()
        {
            return View();
        }
        [HttpPost]
        public ActionResult RegisterView(Customer customer)
        {
            var uniqueCustInfo = db.Customer.SingleOrDefault(u => u.CEmail == customer.CEmail);
            if (uniqueCustInfo == null)
            {
                if (ModelState.IsValid)
                {

                    db.Customer.Add(customer);
                    db.SaveChanges();
                    return RedirectToAction("Index", "Home");

                }
            }
            else
            {
                ViewBag.Message = "Sorry ! Email may not Unique";
            }

            return View();
        }
        public ActionResult Logoutview()
        {
            Session.Clear();
            return RedirectToAction("Index", "Home");
        }

        public ActionResult LoginView()
        {

            return View();
        }
        [HttpPost]
        public ActionResult LoginView(Customer customer)
        {



            var check = db.Customer.Any(u => u.CEmail == customer.CEmail && u.CPassword == customer.CPassword);

            if (check)
            {
                var custData = db.Customer.SingleOrDefault(u => u.CEmail == customer.CEmail && u.CPassword == customer.CPassword);
                Session["UserEmail"] = custData.CEmail.ToString();
                Session["UserId"] = custData.CID.ToString();

                return RedirectToAction("Index", "ProductInfo");

            }
            else
            {
                ViewBag.message = "Incorrect user name or password!!!";
                return View();
            }
        }
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customer.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View(customer);
        }
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            Customer customer = db.Customer.Find(id);
            db.Customer.Remove(customer);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }

}

