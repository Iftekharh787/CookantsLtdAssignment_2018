﻿using CookantsInterviewApp.Models;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace CookantsInterviewApp.Controllers
{
    public class ProductInfoController : Controller
    {
        private ProductDbContext db = new ProductDbContext();

        // GET: /ProductInfo/
        public ActionResult Index()
        {
            return View(db.ProductInfo.ToList());
        }

        // GET: /ProductInfo/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProductInfo productinfo = db.ProductInfo.Find(id);
            if (productinfo == null)
            {
                return HttpNotFound();
            }
            return View(productinfo);


        }

        // GET: /ProductInfo/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /ProductInfo/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "PID,PName,PPrice,PDescription")] ProductInfo productinfo)
        {
            if (ModelState.IsValid)
            {
                ViewBag.PName = productinfo.PName;
                db.ProductInfo.Add(productinfo);
                db.SaveChanges();
                Session["productinfo_Name_ID"] = ViewBag.PName + db.ProductInfo.Max(x => x.PID);

                return RedirectToAction("PhotoUpload");

            }

            return View(productinfo);
        }

        public ActionResult PhotoUpload()
        {

            return View();
        }

        [HttpPost]
        public ActionResult PhotoUpload(HttpPostedFileBase file)
        {

            if (file != null && file.ContentLength > 0)
            {

                var fileName = Path.GetFileName(file.FileName);
                var fileType = Path.GetExtension(fileName);
                fileName = Session["productinfo_Name_ID"] + fileType;
                var path = Path.Combine(Server.MapPath("~/Images/"), fileName);
                file.SaveAs(path);
                Session["productinfo_Name_ID"] = null;
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }

        // GET: /ProductInfo/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProductInfo productinfo = db.ProductInfo.Find(id);
            if (productinfo == null)
            {
                return HttpNotFound();
            }
            return View(productinfo);
        }

        // POST: /ProductInfo/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "PID,PName,PPrice,PDescription")] ProductInfo productinfo)
        {
            if (ModelState.IsValid)
            {
                db.Entry(productinfo).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(productinfo);
        }

        // GET: /ProductInfo/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProductInfo productinfo = db.ProductInfo.Find(id);
            if (productinfo == null)
            {
                return HttpNotFound();
            }
            return View(productinfo);
        }

        // POST: /ProductInfo/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ProductInfo productinfo = db.ProductInfo.Find(id);
            db.ProductInfo.Remove(productinfo);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
